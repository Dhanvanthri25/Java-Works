import java.util.Scanner;
public class ArrayExample
{
public static void main(String args[])
{
int i=0, mean=0;
int scores[]={89,90};
scores[i]=scores[0]+2;
mean=(scores[i]+scores[i])/2;
System.out.println("Top="+ scores[i]);
}
}