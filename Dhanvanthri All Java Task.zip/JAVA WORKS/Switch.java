import java.util.*;
public class Switch
{
public static void main(String args[])
{
Scanner ds=new Scanner(System.in);
String names=ds.next();
switch(names)
{
case"dharnesh":
	System.out.println("one");
	break;
case"siva":
	System.out.println("2");
	break;
default:
System.out.println("Name Thappu Broo");
}
}}
	
