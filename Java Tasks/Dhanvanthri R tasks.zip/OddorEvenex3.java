import java.util.*;
public class OddorEvenex3
{
public static void main(String args[])
{ 
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the value.....");
	int x=sc.nextInt();


	if (x%2==0)
	{
	System.out.println("Even");
	}
	else
	{
	System.out.println("Odd");
	}
	}
	}
	

	

	