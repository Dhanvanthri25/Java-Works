public class OperatorExample5{
public static void main(String args[]){
System.out.println(20<<2);
System.out.println(30<<2);

System.out.println(20>>2);
System.out.println(40>>2);

System.out.println(-20>>2);
System.out.println(-20<<2);

System.out.println(20>>>2);  // will return msb of actual value i.e -3
System.out.println(-20>>>2);
}
}
