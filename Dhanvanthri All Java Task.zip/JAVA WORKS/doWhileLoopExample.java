import java.util.*;
public class doWhileLoopExample
{
public static void main(String args[])
{
 int i=1;
 do{
	i++;
	System.out.println(i);
} while(i<=5);
}
}
