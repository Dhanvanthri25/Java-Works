import java.util.*;
public class Even20ex1{ 
public static void main(String args[])
{
int x[]=new int[20];
	for(int i=0;i<20;i++)
	{
	x[i]=i+2;
	if(x[i]%2==0)
	System.out.println(x[i]);
	}
}
}
	 