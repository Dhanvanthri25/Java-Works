public class OperatorExample4{
public static void main(String arg[]){
int a=20;
int b=10;
System.out.println(a+b);
System.out.println(a-b);
System.out.println(a*b);
System.out.println(a/b);
System.out.println(a%b);
System.out.println(10*10/5+3-1*4/2);
System.out.println(20*10/3+2-1*50/10);
}
}


 