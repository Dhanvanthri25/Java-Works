public class Swapp{
public static void main(String args[]){
int a=56757;
int b=86576;
int c;
c=a;
a=b;
b=c;
System.out.println(a);
System.out.println(b);
}
}

