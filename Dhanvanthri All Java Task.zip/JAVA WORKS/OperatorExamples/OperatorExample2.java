public class OperatorExample2{
public static void main(String args[]){
int x=10;
int y=11;
System.out.println(x);
System.out.println(y);
System.out.println(x++ + ++x);
System.out.println(y++ + y++);
}
}
