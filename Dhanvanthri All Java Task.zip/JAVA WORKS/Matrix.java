public class Matrix
{
public static void main(String args[])
{
int x[]={1,2,3,4};
int[][]x;
x=new int[3][4];
System.out.println(x);
}}

 
