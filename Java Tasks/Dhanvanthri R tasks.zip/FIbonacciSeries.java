public class FibonacciSeries {
    public static void main(String[] args) {
        int n = 30; 
        int firstTerm = 0, secondTerm = 1;
        
        System.out.print("Fibonacci Series of " + n + " terms: ");

        for (int i = 1; i <= n; i++) {
            System.out.print(firstTerm + " ");

            
            int nextTerm = firstTerm + secondTerm;
            firstTerm = secondTerm;
            secondTerm = nextTerm;
        }
    }
}
