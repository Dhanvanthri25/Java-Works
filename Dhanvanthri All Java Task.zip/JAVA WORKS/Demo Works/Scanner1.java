import java.util.*;

public class Scanner1{
public static void main(String args[]){
System.out.println("Welcome And Find Your Multiplication Here!");
Scanner sc = new Scanner(System.in);
System.out.println("Enter X Value");
int x= sc.nextInt();
System.out.println("Enter y Value");
int y= sc.nextInt();
System.out.println(x*y);
}
}




 