public class ForLoop
{
public static void main(String args[])
{
for (int ds=1;ds<=9;ds++)
{
System.out.println(ds+"");
}
}}